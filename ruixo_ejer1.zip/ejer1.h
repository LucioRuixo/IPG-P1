#ifndef EJER_1
#define EJER_1
#include <iostream>
using namespace std;

namespace parcial
{
	void mostrarCreditos();

	float diferencia(float num1, float num2);
}

#endif //EJER_1